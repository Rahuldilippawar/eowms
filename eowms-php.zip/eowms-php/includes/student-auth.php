<?php
// विद्यार्थी Session Bootstrap — Staff Login पासून पूर्णपणे वेगळं
// ($_SESSION['student'] वापरतो, $_SESSION['user'] नाही) — जेणेकरून
// दोन्ही Systems एकमेकांत कधीच मिसळणार नाहीत.

if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'domain' => '',
        'secure' => $isHttps, 'httponly' => true, 'samesite' => 'Lax',
    ]);
}
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/classroom-helpers.php';

function currentStudent() {
    return $_SESSION['student'] ?? null;
}

function requireStudentLogin($rootPath = '') {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    if (empty($_SESSION['student'])) {
        header('Location: ' . $rootPath . 'login.php');
        exit;
    }
}

/** विद्यार्थ्याला Notification पाठवण्यासाठी — users.notifyUser() पासून वेगळं. */
function notifyStudent($pdo, $studentId, $title, $message = null, $link = null) {
    try {
        $pdo->prepare("INSERT INTO student_notifications (student_id, title, message, link) VALUES (?, ?, ?, ?)")
            ->execute([$studentId, $title, $message, $link]);
    } catch (PDOException $e) { /* table not migrated yet */ }
}

/** एका Classroom मधल्या सगळ्या विद्यार्थ्यांना एकत्र Notify करण्यासाठी. */
function notifyClassroomStudents($pdo, $classroomId, $title, $message = null, $link = null) {
    $stmt = $pdo->prepare("SELECT student_id FROM classroom_students WHERE classroom_id = ?");
    $stmt->execute([$classroomId]);
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $sid) {
        notifyStudent($pdo, $sid, $title, $message, $link);
    }
}
